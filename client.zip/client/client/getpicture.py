﻿def onedealed(s1):
    data = s1.recv(1024)
    print(data)
    s1.sendall('length ok')
    data = s1.recv(1024)
    cmd,filename,filesize=str(data,'utf8').split('|')
    path = os.path.join(BASE_DIR,'MNIST_80',filename)  
    filesize=int(filesize)  
    f = open(filename,'wb') 

    print(filename)
    has_receive=0  
    while has_receive!=filesize: 
        data=s1.recv(1024)     
        f.write(data)  
        has_receive+=len(data)  
    f.close()
  