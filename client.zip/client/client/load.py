﻿from __future__ import division
import traceback
import wpf
import socket   #for sockets 
import sys  #for exit 
import json
import os
import select,struct
import time
import uppictuer
#import getpicture
from System.Windows.Media.Imaging import *
from System.Windows.Media import *
from Microsoft.Win32 import OpenFileDialog
from System import Uri,UriKind
from System.IO import Path,FileStream,FileAccess,FileShare,FileMode

from System.Windows import Application, Window, MessageBox

class MyWindowload(Window):
    def __init__(self,s):
        wpf.LoadComponent(self, 'load.xaml')
        self.s1=s
        self.n=0
    def picture(self, sender, e):
        pass
    def Way_TEXT(self, sender, e):
        pass
    def Fileway_TEXT(self, sender, e):
        pass
    def Upload_address(self, sender, e):
        try:
            dialog = OpenFileDialog()
            dialog.Filter = "All Files|*.*"
            if dialog.ShowDialog() == 1:
                self.image1.Source = BitmapImage(Uri(dialog.FileName))
                self.fileway.Text = dialog.FileName 
        except:
             MessageBox.Show("Oh,no!","出错啦！")
             return
        pass    
    def Upload_Button(self, sender, e):
        #标志
        self.s1.sendall('1')
        reply = self.s1.recv(1024) 
        self.n=self.n+1
        filename = str(self.n)+'.bmp'
        f = open(self.fileway.Text,'rb')  
        picture=uppictuer.upload(f,self.s1,filename)
        picture.load()
        pass    
    def Get_Button(self, sender, e):
        self.s1.sendall('2')
        data = self.s1.recv(1024)#标志
        data = self.s1.recv(1024)#长度
        #self.s1.sendall('length ok')
        data1 = self.s1.recv(1024)
        MessageBox.Show(data1) 
        cmd,filename,filesize=str(data1,'utf8').split('|')
                 
        filesize=int(filesize)
        f = open(filename,'wb') 
        has_receive=0
        try:
            while has_receive!=filesize: 
                    data=self.s1.recv(1024)     
                    f.write(data)  
                    has_receive+=len(data)    
            f.close()
        except: 
             MessageBox.Show('error!')
        self.image2.Source = BitmapImage(Uri(os.path.abspath(filename)))
        print ('end')
        pass
    
    def Button_Click(self, sender, e):
        pass
    
    def Button_Click1(self, sender, e):
        self.s1.sendall('3')
        reply = self.s1.recv(1024) 
        pass
    
    def Button_Click2(self, sender, e):
        self.s1.sendall('4')
        reply = self.s1.recv(1024) 
        pass
    
    def Button_Click3(self, sender, e):
        self.s1.sendall('5')
        reply = self.s1.recv(1024) 
        pass
    
    def Button_Click4(self, sender, e):
        super(MyWindowload,self).close
        pass
    
