﻿import traceback
import wpf
import socket   #for sockets 
import sys  #for exit 
import load
import os
from System.Windows import Application, Window, MessageBox
class upload:
    def __init__(self,f,s1,filename):
        self.f=f
        self.s1=s1
        self.filename=filename
        pass
    def load(self):
        contant=self.f.read()
        file_size=len(contant)
        self.s1.sendall(str(file_size).encode('utf-8'))
        reply = self.s1.recv(1024) 
        print reply 
        file_info='post|%s|%s'%(self.filename,file_size)
        self.s1.sendall(bytes(file_info,'utf8')) 
        has_sent=0  
        while has_sent!=int(file_size):  
             data = contant[has_sent:has_sent+1024]
             self.s1.sendall(data)                              
             has_sent+=len(data) 
        self.f.close()  
        pass
    