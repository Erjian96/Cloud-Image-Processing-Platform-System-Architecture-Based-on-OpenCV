﻿import traceback
import wpf
import socket   #for sockets 
import sys  #for exit 
import load
import os
from System.Windows import Application, Window, MessageBox

class connect:
     def __init__(self,host,port):
        self.host=host
        self.port=port
     def socket(self):
        try: 
            self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
        except socket.error, msg: 
            print ('Failed to create socket. Error code: ' + str(msg[0]) + ' , Error message : ' + msg[1] )
            sys.exit(); 
        print ('Socket Created') 
        try: 
            remote_ip = socket.gethostbyname( self.host ) 
        except socket.gaierror: 
            print ('Hostname could not be resolved. Exiting') 
            sys.exit() 
        print ('Ip address of ' + self.host + ' is ' + remote_ip) 
        self.s.connect((remote_ip , self.port)) 
        print ('Socket Connected to ' + self.host + ' on ip ' + remote_ip) 
        return self.s


