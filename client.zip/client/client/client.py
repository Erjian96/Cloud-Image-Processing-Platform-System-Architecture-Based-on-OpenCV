﻿from __future__ import division
import traceback
import wpf
import socket   #for sockets 
import sys  #for exit 
import load
import os
import connect
import LoginCheck
import uppictuer
from System.Windows import Application, Window, MessageBox
host ='127.0.0.1'
port = 8888

class MyWindow(Window):
    def __init__(self):
        wpf.LoadComponent(self, 'client.xaml')
         #连接类:
        soc=connect.connect(host,port) 
        self.s=soc.socket()
    def Name_TEXT(self, sender, e):
        pass
    def Password_Text(self, sender, e):
        pass
    def Enter_Button_Click(self, sender, e):
      
        #登录判断类:
       
        self.s.sendall('0'.encode())
        reply = self.s.recv(1024) 
        try:
            log=LoginCheck.login(self.s,self.name.Text,self.password.Text) 
            reply=log.login1()
        except:
                MessageBox.Show("error！")
        if reply=='2':
            #下一个窗口：
            self.W=load.MyWindowload(self.s) 
            self.Hide()
            self.W.Show()
        else:
            MessageBox.Show("重新输入")
                
        pass    
    def Register_Button_Click(self, sender, e):
        self.s.sendall('11'.encode())
        reply = self.s.recv(1024) 

        message = self.name.Text+',' + self.password.Text
        try : 
            self.s.sendall(bytes(message,'utf8')) 
        except: 
            sys.exit() 
        reply = self.s.recv(1024) 
        if reply=='0':
            MessageBox.Show('注册成功！') 
        else:
            MessageBox.Show('用户名已存在！') 
        pass
 
if __name__ == '__main__':
    Application().Run(MyWindow())

    s.close()