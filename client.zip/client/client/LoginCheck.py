﻿import traceback
import wpf
import socket   #for sockets 
import sys  #for exit 
import load
import os
from System.Windows import Application, Window, MessageBox
class login:
    def __init__(self,s,name,password):
        self.s=s
        self.name=name
        self.password=password
        pass
    def login1(self):    
        #message = 'Name='+self.name+','+'Password=' + self.password
        message = self.name+',' + self.password
        try : 
            self.s.sendall(bytes(message,'utf8')) 
        except: 
            #print 'Send failed' 
            sys.exit() 
        #MessageBox.Show('Message send successfully') 
        reply = self.s.recv(1024) 
        if reply == '0':
            MessageBox.Show("你的用户名不存在！")
        elif reply == '1':
            MessageBox.Show("你的密码错了！")
        elif reply == '2':
            MessageBox.Show("欢迎你!","登录成功！")  
        return reply