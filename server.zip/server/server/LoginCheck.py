﻿import traceback
import sqlite3
import socket   #for sockets 
import sys  #for exit 
import os
#from System.Windows import Application, Window, MessageBox

class login:
    def __init__(self,conn,data):
        self.conn = conn 
        self.data = data
        pass
    def logincheck(self):
        try:
            print (self.data)
            name,password=str(self.data,'utf8').split(',')
            connt = sqlite3.connect('4.db')
            cursor = connt.cursor()
           
            print ("Opened database successfully")
            cursor.execute('select * from client where name=?',(name,))
            
            value=[]
            value = cursor.fetchall()
            cursor.close()
            connt.commit()
            connt.close()
            print(value)
            if value:
                if password==value[0][1]:
                    self.data = '2'
                else:
                    self.data='1'
            else:
                self.data ='0'
           
            self.conn.sendall(self.data.encode())
        except Exception as e:
                    print('error')  