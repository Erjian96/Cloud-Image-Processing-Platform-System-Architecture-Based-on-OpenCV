﻿import socket 
import sys 
import os
import connect
import LoginCheck
import getpictuer
import cv2
import numpy as np
import picture
import select
import sqlite3
#import operation



#cursor.execute('create table client (name varchar(20) primary key, password varchar(20))')

host = '127.0.0.1'   # Symbolic name meaning all available interfaces 
port = 8888 # Arbitrary non-privileged port 
soc=connect.connect(host,port) 
s=soc.socket()
s.listen(10) 
print ('Socket now listening') 
input_list = [s]
output_list=[]
n=11111122222
BASE_DIR = os.path.dirname(os.path.abspath(__file__)) 
while 1:
    
    stdinput,stdoutput,stderr = select.select(input_list, output_list,[]) 
    for obj in stdinput:            
        try: 
            if obj == s:  # 接收客户端的连接
                conn,addr = obj.accept()  
                print(addr)     
                #flag = conn.recv(1024).decode()
                #print(flag)
                #conn.sendall(flag.encode())
                input_list.append(conn)  
            else:  #不是连接，是数据
                try:    
                    flag = obj.recv(1024).decode()
                    print(flag)
                    obj.sendall(flag.encode()) 
                       ##登录：用户名、密码：
                    if flag == '0':
                        data = obj.recv(1024)
                        #data=str(data,'utf8')
                        print(data)
                        p=LoginCheck.login(obj,data)
                        p.logincheck()
                      
                    elif flag == '11':
                       
                         data = obj.recv(1024)
                         name,password=str(data,'utf8').split(',')

                         connt = sqlite3.connect('4.db')
                         cursor = connt.cursor()
                         print ("Opened database successfully")
                         cursor.execute('select * from client where name=?',(name,))
             
                         value=[]
                         value = cursor.fetchall()
                         cursor.close()
                         connt.commit()
                         connt.close()
                         print(value)
                         if value:
                            data ='1'
                         else:
                            connt = sqlite3.connect('4.db')
                            cursor = connt.cursor()
                            print ("Opened database successfully")
                            cursor.execute('insert into client(name,password) values (?,?)',(name,password))
                            #connt.commit()
                            #cursor.execute('insert into usertable(name,password) values (?,?)',(name,password))
                            cursor.close()
                            connt.commit()
                            connt.close()
                            data = '0'
                         obj.sendall(data.encode())      
                    elif flag == '1':
                        data = obj.recv(1024).decode()
                        print(data)
                        obj.sendall('length ok'.encode())
                        data = obj.recv(1024)
                        cmd,filename,filesize=str(data,'utf8').split('|')
                        path = os.path.join(BASE_DIR,'MNIST_80',filename)  
                        filesize=int(filesize)  
                        f = open(filename,'wb')  
                        print(filename)
                        onefile=picture.onepicture(f,filename,filesize)
                        get=getpictuer.getone(obj,filesize,f)
                        get.picture()
                    elif flag == '2':
                        f = open(filename,'rb')  
                        contant=f.read()
                        file_size=len(contant)
                        print(file_size)
                        obj.sendall(bytes(str(file_size),'utf8'))
                        n=n+1
                        filename = 'back'+str(n)+'.bmp'
                        print(filename)
                        file_info='post|%s|%s'%(filename,file_size)
                        obj.sendall(bytes(file_info,'utf8'))  
                        has_sent=0  
                        while has_sent!=int(file_size):  
                                data = contant[has_sent:has_sent+1024]
                                obj.sendall(data)                              
                                has_sent+=len(data) 
                        f.close() 
                    elif flag =='3':
                        img = cv2.imread(filename, 2)
                        cv2.imwrite(filename,img)
                    elif flag =='4':
                        img = cv2.imread(filename)
                        imgray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
                        ret,thresh = cv2.threshold(imgray,127,255,0)
                        im2, contours, hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
                        cv2.drawContours(img, contours, -1, (255,0,0), 1)
                        cv2.imwrite(filename,img)
                    elif flag == '5':
                        def detect(img, cascade):
                            rects = cascade.detectMultiScale(img,1.3, 6,cv2.CASCADE_SCALE_IMAGE,(20,20))
                            if  len(rects) == 0:
                                return []
                            rects[:, 2:] += rects[:, :2]
                            print(rects)
                            return rects
                        def draw_rects(img, rects):
                            r =0
                            x = 0
                            y = 0
                            num = 0
                            for x1, y1, x2, y2 in rects:
                                num = num + 1
                                co1 = 0
                                co2 = 0
                                co3 = 0
                                if(num%3 == 0): co1 = 255
                                if(num%3 == 1): co2 = 255
                                if(num%3 == 2): co3 = 255
                                x = np.int((x1 + x2) * 0.5)
                                y = np.int((y1 + y2) * 0.5)
                                r = np.int(( abs(x1 - x2) + abs(y1-y2) ) * 0.25)
                                cv2.circle(img, (x, y), r, (co1,co2,co3), 2)
                        img = cv2.imread(filename)
                        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                        face_cascade=cv2.CascadeClassifier('haarcascade_frontalface_alt.xml')
                        #face_cascade.load('C:/Users/Administrator/Desktop/server/server/haarcascade_frontalface_alt.xml')
                        face_cascade.load('haarcascade_frontalface_alt.xml')
                        rects = detect(gray, face_cascade)
                        vis = img.copy()
                        draw_rects(vis,rects)
                        cv2.imwrite(filename, vis)
                    else:
                        stdinput.remove(obj)
                        input_list.remove(obj)
                except Exception as e:
                    input_list.remove(obj)  
        except Exception:
            input_list.remove(obj)  

conn.close()
s.close()
