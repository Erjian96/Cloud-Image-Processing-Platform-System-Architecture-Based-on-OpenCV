import socket   #for sockets 
import sys  #for exit 
import os
class onepicture:
    def __init__(self,f,filename,file_size):
        self.f=f
        self.filename = filename 
        self.file_size = file_size
        pass
    def filename(self):
        return filename 
    def file_size(self):
        return file_size 
    def f(self):
        return f 