﻿import traceback
import socket   #for sockets 
import sys  #for exit 
import os
#from System.Windows import Application, Window, MessageBox

class getone:
    def __init__(self,conn,filesize,f):
        self.conn = conn 
        self.filesize = filesize
        self.f=f
        pass
    def picture(self):
        has_receive=0  
        while has_receive!=self.filesize: 
            data=self.conn.recv(1024)
            self.f.write(data)  
            has_receive+=len(data)  
        self.f.close()  
        print ('end')