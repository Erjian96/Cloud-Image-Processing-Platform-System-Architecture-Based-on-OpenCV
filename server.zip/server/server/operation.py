﻿import traceback
import wpf
import socket   #for sockets 
import sys  #for exit 
import os
from System.Windows import Application, Window, MessageBox

class operation:
        def __init__(self,conn):
            self.s1=conn
            pass
        def sendone(self):
            f = open('1.bmp','rb')  
            contant=f.read()
            file_size=len(contant)
            self.s1.sendall(file_size.encode())
            reply = self.s1.recv(1024).decode() 
            print (reply) 
            file_info='post|%s|%s'%('1.bmp',file_size)
            self.s1.sendall(bytes(file_info,'utf8'))     
            has_sent=0  
            while has_sent!=int(file_size):  
                 data = contant[has_sent:has_sent+1024]
                 self.s1.sendall(data.encode())                              
                 has_sent+=len(data) 
            self.f.close()  