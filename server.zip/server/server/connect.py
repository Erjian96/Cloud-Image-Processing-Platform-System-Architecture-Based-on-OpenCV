﻿import traceback
import socket   #for sockets 
import sys  #for exit 
import os
#from System.Windows import Application, Window, MessageBox

class connect:
        def __init__(self,host,port):
            self.host=host
            self.port=port
        def socket(self):
            self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
            print( 'Socket created') 
            try: 
                self.s.bind((self.host, self.port)) 
            except socket.error: 
                sys.exit() 
            print ('Socket bind complete') 
            return self.s